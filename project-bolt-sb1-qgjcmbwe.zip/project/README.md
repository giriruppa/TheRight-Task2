# Person API

A RESTful API built with Node.js, Express, and MongoDB for managing person records.

## Features

- Complete CRUD operations for person records
- MongoDB integration with Mongoose
- Input validation and error handling
- RESTful API design

## Requirements

- Node.js (v14 or higher)
- MongoDB (local or Atlas)

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file in the root directory with the following variables:
   ```
   PORT=3000
   MONGODB_URI=mongodb://localhost:27017/person-api
   NODE_ENV=development
   ```

## Running the Application

Development mode:
```
npm run dev
```

Production mode:
```
npm start
```

## API Endpoints

### Get all persons
```
GET /person
```

### Get a single person
```
GET /person/:id
```

### Create a new person
```
POST /person
```
Request body:
```json
{
  "name": "John Doe",
  "age": 30,
  "gender": "male",
  "mobile": "1234567890"
}
```

### Update a person
```
PUT /person/:id
```
Request body (all fields optional):
```json
{
  "name": "John Smith",
  "age": 31,
  "gender": "male",
  "mobile": "0987654321"
}
```

### Delete a person
```
DELETE /person/:id
```

## Schema Validation

- **name**: String, required
- **age**: Number, required, must be positive
- **gender**: String, required, must be 'male', 'female', or 'other'
- **mobile**: String, must be a valid phone number format

## Error Handling

The API returns appropriate status codes and error messages:

- `400` - Bad Request (validation errors)
- `404` - Not Found
- `500` - Server Error

Each error response follows this format:
```json
{
  "success": false,
  "error": "Error Type",
  "message": "Detailed error message"
}
```