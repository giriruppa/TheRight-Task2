// run `node index.js` in the terminal

console.log(`Hello Node.js v${process.versions.node}!`);
