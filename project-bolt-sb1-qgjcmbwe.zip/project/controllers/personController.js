const Person = require('../models/person');

// Get all persons
exports.getAllPersons = async (req, res) => {
  try {
    const persons = await Person.find();
    res.status(200).json({
      success: true,
      count: persons.length,
      data: persons
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
};

// Get a single person by ID
exports.getPersonById = async (req, res) => {
  try {
    const person = await Person.findById(req.params.id);
    
    if (!person) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'Person not found with the provided ID'
      });
    }
    
    res.status(200).json({
      success: true,
      data: person
    });
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not valid'
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
};

// Create a new person
exports.createPerson = async (req, res) => {
  try {
    const person = await Person.create(req.body);
    
    res.status(201).json({
      success: true,
      data: person
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      
      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        message: messages.join(', ')
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
};

// Update a person by ID
exports.updatePerson = async (req, res) => {
  try {
    let person = await Person.findById(req.params.id);
    
    if (!person) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'Person not found with the provided ID'
      });
    }
    
    person = await Person.findByIdAndUpdate(
      req.params.id, 
      req.body, 
      { 
        new: true, 
        runValidators: true 
      }
    );
    
    res.status(200).json({
      success: true,
      data: person
    });
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not valid'
      });
    }
    
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      
      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        message: messages.join(', ')
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
};

// Delete a person by ID
exports.deletePerson = async (req, res) => {
  try {
    const person = await Person.findById(req.params.id);
    
    if (!person) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'Person not found with the provided ID'
      });
    }
    
    await person.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        error: 'Invalid ID',
        message: 'The provided ID is not valid'
      });
    }
    
    res.status(500).json({
      success: false,
      error: 'Server Error',
      message: error.message
    });
  }
};